﻿namespace MahApps.Metro.Tests
{
    public partial class DateAndTimePickerWindow
    {
        public DateAndTimePickerWindow()
        {
            InitializeComponent();
        }
    }
}
