﻿namespace MahApps.Metro.Tests
{
    public partial class TextBoxHelperTestWindow
    {
        public TextBoxHelperTestWindow()
        {
            InitializeComponent();
        }
    }
}
