﻿namespace MahApps.Metro.Tests
{
    public partial class TestApp
    {
        public TestApp()
        {
            this.InitializeComponent();
        }
    }
}
