﻿using System.Windows.Controls;

namespace MetroDemo.ExampleViews
{
    /// <summary>
    /// Interaction logic for ColorExample.xaml
    /// </summary>
    public partial class ColorExample : UserControl
    {
        public ColorExample()
        {
            InitializeComponent();
        }
    }
}
