﻿using System.Windows.Controls;

namespace MetroDemo.ExampleViews
{
    /// <summary>
    /// Interaction logic for TextExamples.xaml
    /// </summary>
    public partial class TextExamples : UserControl
    {
        public TextExamples()
        {
            InitializeComponent();
        }
    }
}
