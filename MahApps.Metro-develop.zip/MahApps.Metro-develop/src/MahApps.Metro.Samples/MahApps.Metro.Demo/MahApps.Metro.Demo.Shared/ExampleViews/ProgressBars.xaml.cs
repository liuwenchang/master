﻿using System.Windows.Controls;

namespace MetroDemo.ExampleViews
{
    /// <summary>
    /// Interaction logic for ProgressBars.xaml
    /// </summary>
    public partial class ProgressBars : UserControl
    {
        public ProgressBars()
        {
            InitializeComponent();
        }
    }
}