﻿namespace MahApps.Metro.Controls
{
    public enum TimePickerFormat
    {
        Long,
        Short
    }
}